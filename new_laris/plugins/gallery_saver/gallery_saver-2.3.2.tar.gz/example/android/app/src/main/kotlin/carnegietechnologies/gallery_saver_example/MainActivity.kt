package carnegietechnologies.gallery_saver_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {


}
